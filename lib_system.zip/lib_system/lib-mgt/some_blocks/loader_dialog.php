<div id="overlay">
    <div id="dialog">
      <div id="subway-loader"></div>
      <div id="dialog-box">
        <div id="dialog_icon">&#10003;</div>
        <div id="dialog_message">تم!

        </div>
        <button id="dialog_button">OK</button>
      </div>
    </div>
  </div>